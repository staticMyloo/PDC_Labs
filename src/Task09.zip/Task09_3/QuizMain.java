package Task09_3;

public class QuizMain {

    public static void main(String[] args) {
        MathQuiz mQuiz = new MathQuiz();
        mQuiz.setVisible(true);
    }

}
