/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Task09_3;

/**
 *
 * @author myles
 */
public class NewQuizMain 
{
    public static void main(String[] args) {
        View mathQuiz = new View();
    }
}
