/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Task09_3;

/**
 *
 * @author myles
 */
public class Data {
    
    boolean loginFlag = false;
    boolean quitFlag = false;
    int currentScore = 0;
    int num1 = 0;
    int num2 = 0;
    
}
